﻿Imports System.Net
Imports System.Net.Http
Imports System.Net.Http.Headers
Imports System.Net.Security
Imports System.Security.Cryptography.X509Certificates
Imports System.Text
Imports Newtonsoft.Json

Public Class Form1
    Dim appId As String = "__o _numero_da_sua_API_KEY"
    Dim baseUrl As String = "https://localhost:5001"
    '************************
    ' Para teste
    Public Shared Function ValidateRemoteCertificate(ByVal sender As Object, ByVal certificate As X509Certificate, ByVal chain As X509Chain, ByVal sslPolicyErrors As SslPolicyErrors) As Boolean
        Return True
    End Function
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles Me.Load

    End Sub
    Private Sub Btn_ApiBasica_Click(sender As Object, e As EventArgs) Handles Btn_ApiBasica.Click
        Dim client As HttpClient = New HttpClient()
        '***********************
        'para teste
        ServicePointManager.ServerCertificateValidationCallback = AddressOf ValidateRemoteCertificate

        client.BaseAddress = New Uri(baseUrl)
        client.DefaultRequestHeaders.Accept.Clear()
        client.DefaultRequestHeaders.Accept.Add(New MediaTypeWithQualityHeaderValue("application/json"))
        Dim responseTask = client.GetAsync("api/problems")
        responseTask.Wait()

        Dim result = responseTask.Result
        Dim content = responseTask.Result.Content.ReadAsAsync(Of String)
        Label1.Text = content.Result
        Label2.Text = result.RequestMessage.RequestUri.ToString
        Label6.Text = result.StatusCode.ToString
        Label7.Text = result.RequestMessage.Method.Method
    End Sub

    Private Sub Btn_validaCnpj_Click_1(sender As Object, e As EventArgs) Handles Btn_validaCnpj.Click
        Dim client As HttpClient = New HttpClient()
        '***********************
        'para teste
        ServicePointManager.ServerCertificateValidationCallback = AddressOf ValidateRemoteCertificate

        client.BaseAddress = New Uri(baseUrl)
        client.DefaultRequestHeaders.Accept.Clear()
        client.DefaultRequestHeaders.Accept.Add(New MediaTypeWithQualityHeaderValue("application/json"))
        Dim cnpj As String = Tb_CNPJ.Text.Replace("/", "%2F")

        Dim responseTask = client.GetAsync("api/problems/cnpjvalidate/" & cnpj)
        responseTask.Wait()

        Dim result = responseTask.Result
        Dim content = responseTask.Result.Content.ReadAsAsync(Of String)
        Label12.Text = content.Result
        Label15.Text = result.RequestMessage.RequestUri.ToString
        Label13.Text = result.StatusCode.ToString
        Label9.Text = result.RequestMessage.Method.Method
    End Sub

    Private Sub Btn_validaCnpjPost_Click(sender As Object, e As EventArgs) Handles Btn_validaCnpjPost.Click
        Dim client As HttpClient = New HttpClient()
        '***********************
        'para teste
        ServicePointManager.ServerCertificateValidationCallback = AddressOf ValidateRemoteCertificate

        client.BaseAddress = New Uri(baseUrl)
        client.DefaultRequestHeaders.Accept.Clear()
        client.DefaultRequestHeaders.Accept.Add(New MediaTypeWithQualityHeaderValue("application/json"))

        Dim cnpj As String = JsonConvert.SerializeObject(Tb_CnpjPost.Text)
        Dim RestContent As New Http.StringContent(cnpj, Encoding.UTF8, "application/json")

        Dim responseTask = client.PostAsync("api/problems/cnpjvalidatepost/", RestContent)
        responseTask.Wait()

        Dim result = responseTask.Result
        Dim content = responseTask.Result.Content.ReadAsAsync(Of String)
        Label22.Text = content.Result
        Label25.Text = result.RequestMessage.RequestUri.ToString
        Label23.Text = result.StatusCode.ToString
        Label19.Text = result.RequestMessage.Method.Method
    End Sub
End Class
